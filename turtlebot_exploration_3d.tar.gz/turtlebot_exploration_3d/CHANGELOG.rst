^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_exploration_3d
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.8 (2017-01-03)
------------------
* update install list
* Contributors: baishi.bona@gmail.com

0.0.7 (2016-12-29)
------------------

0.0.6 (2016-12-29)
------------------
* add install, and launch 
* update parameters, bug false alarm cleared
* fix bug, n--num_of_samples
* Contributors: baishi.bona@gmail.com

0.0.5 (2016-12-21)
------------------
* adding visualization_msgs to package for bloom build
* Contributors: baishi.bona@gmail.com

0.0.4 (2016-12-20)
------------------
* remove laser_geometry from dep
* Contributors: baishi.bona@gmail.com

0.0.3 (2016-12-20)
------------------

0.0.2 (2016-12-20)
------------------
* prepare release
* prepare for release-packagexml
* prepare for release
* update resolution to 0.1, as well as 15 evaluations per step
* typo in pdf
* update bayesian approach
* fix typo @OctomapOccupied_cubelist_3d
* update ROS code style..
* update tutorial
* update tutorial
* update readme.md
* update license
* update tutorial typo
* candidate check
* udpate changelog
* first commit, ver 0.0.1
* Contributors: Bona, Shawn
